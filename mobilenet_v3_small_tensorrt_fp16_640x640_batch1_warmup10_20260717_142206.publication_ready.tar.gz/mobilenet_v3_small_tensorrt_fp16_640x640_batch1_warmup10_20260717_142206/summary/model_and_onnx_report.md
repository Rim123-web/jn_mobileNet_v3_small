# Model and ONNX

{
  "selected": {
    "path": "/home/jetson/Downloads/classification_benchmark/mobileNet_v3_small/mobilenet_v3_small_tensorrt_fp32_640x640_batch1_warmup10_20260717_133615/onnx/mobilenet_v3_small_source.onnx",
    "size_bytes": 6123503,
    "modified_time": 1781371748.27417,
    "sha256": "28ef2fe9519b184d0e3c41690726c8911157a103c6ec66ccf8b86387de1d47e7"
  },
  "packaged": {
    "path": "/home/jetson/Downloads/classification_benchmark/mobileNet_v3_small/mobilenet_v3_small_tensorrt_fp16_640x640_batch1_warmup10_20260717_142206/onnx/mobilenet_v3_small_source.onnx",
    "size_bytes": 6123503,
    "modified_time": 1781371748.27417,
    "sha256": "28ef2fe9519b184d0e3c41690726c8911157a103c6ec66ccf8b86387de1d47e7"
  },
  "copy_hash_matches": true,
  "fp32_reference_package": "/home/jetson/Downloads/classification_benchmark/mobileNet_v3_small/mobilenet_v3_small_tensorrt_fp32_640x640_batch1_warmup10_20260717_133615",
  "reexported": false
}

# ONNX Validation

- onnx.checker: PASS
- Fixed FP32 input: [1,3,640,640]
- FP32 output: [1,3]
- ONNX Runtime CPU dummy inference: PASS
- Embedded Softmax: False
