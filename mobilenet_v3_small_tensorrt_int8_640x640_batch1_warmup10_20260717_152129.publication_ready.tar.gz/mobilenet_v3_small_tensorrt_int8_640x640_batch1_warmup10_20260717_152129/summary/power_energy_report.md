# Power and Energy

{
  "power_boundary": "Jetson module-level Power TOT (POM_5V_IN), not GPU-only power",
  "monitor": "jtop/jetson-stats 4.3.2",
  "interval_seconds": 0.5,
  "active_sample_count": 70,
  "idle_sample_count": 60,
  "mean_power_tot_w": 5.1019,
  "median_power_tot_w": 5.198,
  "min_power_tot_w": 3.734,
  "max_power_tot_w": 6.355,
  "p95_power_tot_w": 6.08665,
  "gross_total_energy_j": 185.7267317159176,
  "gross_energy_per_image_j": 0.7115966732410636,
  "idle_mean_power_w": 2.898616666666667,
  "idle_corrected_total_energy_j": 79.03479888346989,
  "idle_corrected_energy_per_image_j": 0.3028153213926049,
  "images_per_gross_joule": 1.405290437131141,
  "images_per_idle_corrected_joule": 3.302342812117766,
  "integration": "trapezoidal integration over timestamped samples with boundary extension",
  "warmup_energy_excluded": true
}
